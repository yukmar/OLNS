<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	protected $stat_user = null;
	protected $user = null;

	function __construct(){
		parent::__construct();
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index()
	{
		if ($this->session->userdata('user')) {
			$this->user = $this->session->userdata('user');
			$this->stat_user = $this->usermod->get_upriv($this->user);
			if ($this->stat_user == 'admin') {
				$data['count_tutorial'] = $this->bankmod->count(); 
				$data['count_user'] = $this->usermod->count();
				$data['count_submit'] = $this->submod->count();
				$this->tampilan->view($this->stat_user, 'admin/home_view', array('dt' => $data));
			} else {
				$this->tampilan->view($this->stat_user, 'dashboard/home_view', array(
					'u' => $this->usermod->get_user($this->user),
					'point' => $this->submod->count_point($this->user),
					'recent_tuts' => $this->bankmod->recent_tut(),
					'ranks' => $this->usermod->get_big5()
				));
			}
		} else {
			$this->load->view('welcome_view');
		}
	}

	function login()
	{
		$datalog['user'] = $this->input->post('tbuser');
		$datalog['pass'] = $this->input->post('tbpuser');
		if ($this->usermod->checkuser($datalog)) {
			$this->session->set_userdata(array('user' => $datalog['user']));
			redirect(site_url());
		} else {
			$this->login_failed();
		}
	}

	function login_failed()
	{
		$this->load->view('loginfailed_view');
	}

	function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url());
	}
}
