<?php
/**
 * 
 */
class User extends CI_Controller
{
	protected $stat;
	function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('user')) {
			$this->stat = $this->usermod->get_upriv($this->session->userdata('user'));
			if ($this->stat !== 'admin') {
				$this->session->sess_destroy();
				redirect(site_url());
			}
		} else {
			$this->session->sess_destroy();
			redirect(site_url());
		}
	}

	public function index()
	{

		$user = $this->input->get('u');
		$li_tut = null;
		$var = null;
		$alert = null;
		switch ($this->input->get('aksi')) {
			case 'det':
				$var = 'detail';
				break;
			case 'ubah':
				$var = 'user';
				break;
			case 'detsub':
				$li_tut = $this->submod->gettut_byuser($user);
				break;
			default:
				$var = null;
				break;
		}
		switch ($this->input->get('alt')) {
			case 'adder':
					$alert = "<div class='alert alert-danger' role='alert'>Maaf, username sudah ada.</div>";
				break;
			case 'addberhasil':
					$alert = "<div class='alert alert-success' role='alert'>Penambahan user baru berhasil!</div>";
				break;
			case 'ubahberhasil':
					$alert = "<div class='alert alert-success' role='alert'>Proses pengubahan data user berhasil!</div>";
				break;
			case 'ubahgagal':
					$alert = "<div class='alert alert-danger' role='alert'>Maaf, proses pengubahan datauser gagal!</div>";
				break;
			case 'delberhasil':
					$alert = "<div class='alert alert-success' role='alert'>Proses penghapusan data user berhasil!</div>";
				break;
			case 'delgagal':
					$alert = "<div class='alert alert-danger' role='alert'>Maaf, proses penghapusan data user gagal!</div>";
				break;
			default:
				$alert = null;
				break;
		}
		$this->tampilan->view($this->stat, 'admin/user_view', array(
			'users' => $this->usermod->get_all(), 
			$var => $this->usermod->get_usernpriv($user),
			'list_tut' => $li_tut,
			'alert' => $alert)
		);
	}

	public function select()
	{
		$user = $this->input->get();
	}

	public function tambah()
	{
		# code... tbuser tbnama tbpass
		$new['username'] = $this->input->post('tbuser');
		$new['nama'] = $this->input->post('tbnama');
		$new['id_priv'] = $this->input->post('priv');
		$new['password'] = $this->input->post('tbpass');

		if ($this->usermod->get_user($new['username'])) {
			redirect(site_url('user/?alt=adder'));
		} else {
			$res = $this->usermod->insert($new);
			if ($res) {
				redirect(site_url('user/?alt=addberhasil'));
			} else {
				var_dump($res);
			}
		}
	}

	function ubah()
	{
		$ubah['username'] = $this->input->post('ubuser');
		$ubah['nama'] = $this->input->post('ubnama');
		$ubah['id_priv'] = $this->input->post('rdstat');
		$ubah['password'] = $this->input->post('ubpass');
		var_dump($ubah);
		$res = $this->usermod->ubah($ubah);
		if ($res) {
			redirect(site_url('user/?alt=ubahberhasil'));
		} else {
			redirect(site_url('user/?alt=ubahgagal'));
		}
	}

	function delete()
	{
		$user = $this->input->get('u');
		$res = $this->usermod->delete($user);
		if ($res) {
			redirect(site_url('user/?alt=delberhasil'));
		} else {
			redirect(site_url('user/?alt=delgagal'));
		}
	}
}