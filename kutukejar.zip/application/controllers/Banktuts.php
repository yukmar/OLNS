<?php
/**
 * 
 */
class Banktuts extends CI_Controller
{
	protected $stat;
	function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('user')) {
			$this->stat = $this->usermod->get_upriv($this->session->userdata('user'));
			if ($this->stat !== 'admin') {
				$this->session->sess_destroy();
				redirect(site_url());
			}
		} else {
			$this->session->sess_destroy();
			redirect(site_url());
		}
	}

	public function index()
	{
		$no = $this->input->get('id');
		$li_user = null;
		$alert = null;
		$var = null;
		switch ($this->input->get('aksi')) {
			case 'det':
				$var = 'dtdet';
				break;
			case 'ubah':
				$var = 'dtubah';
				break;
			case 'detuser':
				$li_user = $this->submod->getuser_bytut($no);
				break;
			default:
				$var = null;
				break;
		}
		switch ($this->input->get('alt')) {
			case 'addberhasil':
				$alert = "<div class='alert alert-success' role='alert'>Penambahan tutorial baru berhasil!</div>";
				break;
			case 'addgagal':
				$alert = "<div class='alert alert-danger' role='alert'>Penambahan tutorial baru gagal!</div>";
				break;
			case 'ubahberhasil':
				$alert = "<div class='alert alert-success' role='alert'>Proses pengubahan data tutorial berhasil!</div>";
				break;
			case 'ubahgagal':
				$alert = "<div class='alert alert-danger' role='alert'>Maaf, proses pengubahan data tutorial gagal!</div>";
				break;
			case 'delberhasil':
				$alert = "<div class='alert alert-success' role='alert'>Proses penghapusan data tutorial berhasil!</div>";
				break;
			case 'delgagal':
				$alert = "<div class='alert alert-danger' role='alert'>Maaf, proses penghapusan data tutorial gagal!</div>";
				break;
			default:
				$alert = null;
				break;
			}
		$this->tampilan->view($this->stat,'admin/bank_view', array(
			'dt' => $this->bankmod->get_all(), 
			'kat' => $this->catmod->get_cat(),
			$var => $this->bankmod->get_tutncat($no),
			'list_u' => $li_user,
			'alert' => $alert
		));
	}

	function ubah()
	{
		// id_tut name_tut id_cat desc_tut pdf video keys point
		$ubah['id_tut'] = $this->input->post('ubno');
		$ubah['name_tut'] = $this->input->post('ubname');
		$ubah['id_cat'] = $this->input->post('nocat');
		$ubah['desc_tut'] = $this->input->post('ubdesc');
		$ubah['pdf'] = $this->input->post('ubpdf');
		$ubah['video'] = $this->input->post('ubvideo');
		$ubah['keys'] = $this->input->post('ubkey');
		$ubah['point'] = $this->input->post('ubpoint');

		var_dump($ubah);
		$res = $this->bankmod->ubah($ubah);
		if ($res) {
			redirect(site_url('banktuts/?alt=ubahberhasil'));
		} else {
			redirect(site_url('banktuts/?alt=ubahgagal'));
		}

	}

	function do_tambah()
	{
		$newdt['name_tut'] = $this->input->post('tbnametut');
		$newdt['id_cat'] = $this->catmod->getid_byname($this->input->post('tbcat'));
		$newdt['desc_tut'] = $this->input->post('tbdesc');
		$newdt['pdf'] = $this->input->post('tbpdf');
		$newdt['video'] = $this->input->post('tbvid');
		$newdt['keys'] = $this->input->post('tbkunci');
		$newdt['point'] = $this->input->post('tbpoint');

		if ($newdt['id_cat']) {
			$res = $this->bankmod->tambah($newdt);
			if ($res) {
				redirect(site_url('banktuts/?alt=addberhasil'));
			} else {
				redirect(site_url('banktuts/?alt=addgagal'));
			}
		} else {
			redirect(site_url('banktuts/?alt=addgagal'));
		}
	}

	function hapus(){
		$res = $this->bankmod->hapus($this->input->get('id'));
		if ($res) {
			redirect(site_url('banktuts/?alt=delberhasil'));
		} else {
			redirect(site_url('banktuts/?alt=delgagal'));
		}
	}

}