<?php
/**
 * 
 */
class Banktuts_mod extends CI_Model
{
	protected $tbl = 'bank_tuts';
	function __construct()
	{
		parent::__construct();
	}

	public function list_tuts($idcat)
	{
		$q = $this->db->get_where($this->tbl, array('id_cat' => $idcat));
		return $q->result();
	}

	public function get_tuts($idtut)
	{
		$q = $this->db->get_where($this->tbl, array('id_tut' => $idtut));		
		return $q->result();
	}

	public function check_key($dtkey)
	{
		$q = $this->db->get_where($this->tbl, array('id_tut' => $dtkey['no'],
			'keys' => $dtkey['newkey']));
		return $q->num_rows();
	}

	public function get_all($kolom=null, $order=null)
	{
		$q = $this->db->query('select bank.id_tut, bank.name_tut, kat.name_cat, bank.point, count(log.id_tut) as jumsub  from bank_tuts bank right join kategori_kejar kat on bank.id_cat = kat.id_cat  left join log_submit_keys log on bank.id_tut = log.id_tut  group by bank.id_tut order by name_cat ASC');
		return $q->result();
	}

	public function recent_tut()
	{
		$q = $this->db->query('select name_tut, point from bank_tuts order by waktu_dibuat limit 3');
		return $q->result();
	}

	public function get_tutncat($idtut)
	{
		$this->db->select('*')->from($this->tbl)->join('kategori_kejar', 'kategori_kejar.id_cat = bank_tuts.id_cat', 'left')->where('id_tut', $idtut);
		$q = $this->db->get();
		return $q->result();
	}

	function ubah($ubahdt)
	{
		$this->db->update($this->tbl, $ubahdt, array('id_tut' => $ubahdt['id_tut']));
		return $this->db->affected_rows();
	}

	function tambah($newdt)
	{
		$this->db->insert($this->tbl, $newdt);
		return $this->db->affected_rows();
	}

	function hapus($idtut)
	{
		$this->db->delete($this->tbl, array('id_tut' => $idtut));
		return $this->db->affected_rows();
	}

	function count()
	{
		return $this->db->count_all($this->tbl);
	}
}