<?php
/**
 * 
 */
class User_mod extends CI_Model
{
	protected $tbl;
	function __construct()
	{
		parent::__construct();
		$this->tbl = 'user';
	}

	public function checkuser($data)
	{
		$q = $this->db->get_where($this->tbl, array
			('username' => $data['user'], 'password' => $data['pass']));
		return $q->num_rows();
	}

	public function get_user($user)
	{
		$q = $this->db->get_where($this->tbl, array('username' => $user));
		return $q->result();
	}

	function get_upriv($user){
		foreach ($this->get_user($user) as $ob => $prop) {
			$q = $this->db->get_where('privilege_lvl', array('id_priv' => $prop->id_priv));
			foreach ($q->result() as $key => $value) {
				return $value->nama_priv;
			}
		}
	}

	public function get_all()
	{
		// $this->db->select('*')->from($this->tbl)->join('privilege_lvl', 'privilege_lvl.id_priv = user.id_priv', 'left')->order_by('waktu_dibuat', 'ASC');
		// $q = $this->db->get();
		$q = $this->db->query('select u.username, u.nama, priv.nama_priv, sum(bank.point) as jumlah, u.waktu_dibuat from user u right join log_submit_keys log on u.username = log.username right join privilege_lvl priv on u.id_priv = priv.id_priv left join bank_tuts bank on bank.id_tut = log.id_tut group by username order by waktu_dibuat ASC');
		return $q->result();
	}

	public function get_bypriv($dt)
	{
		$q = $this->db->get_where($this->tbl, array('id_priv' => $dt));
		return $q->result();
	}

	public function get_usernpriv($user)
	{
		$this->db->select('*')->from($this->tbl)->join('privilege_lvl', 'privilege_lvl.id_priv = user.id_priv', 'left')->where('username', $user);
		$q = $this->db->get();
		return $q->result();
	}

	public function insert($newdt)
	{
		$this->db->insert($this->tbl, $newdt);
		return $this->db->affected_rows();
	}

	public function ubah($ubahdt)
	{
		$this->db->update($this->tbl, $ubahdt, array('username' => $ubahdt['username']));
		return $this->db->affected_rows();
	}

	function delete($user)
	{
		$this->db->delete($this->tbl, array('username' => $user));
		return $this->db->affected_rows();
	}

	function count()
	{
		return $this->db->count_all($this->tbl);
	}

	public function get_big5()
	{
		$q = $this->db->query('select u.nama, sum(bank.point) as total from user u right join log_submit_keys log on u.username = log.username left join bank_tuts bank on bank.id_tut = log.id_tut group by nama order by total DESC limit 5');
		return $q->result();
	}
}