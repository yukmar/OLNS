<div class="row">
	<div class="container">
		<h2>Dashboard</h2>
	</div>
	<div class="col-md-auto">
		<table class="table table-borderless">
			<tbody>
				<tr>
					<td>Jumlah Tutorial Saat Ini</td>
					<td>: <?=$dt['count_tutorial']?></td>
				</tr>
				<tr>
					<td>Jumlah User Saat Ini</td>
					<td>: <?=$dt['count_user']?></td>
				</tr>
				<tr>
					<td>Jumlah Submit Saat Ini</td>
					<td>: <?=$dt['count_submit']?></td>
				</tr>
				<tr>
					<td></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>