		</div>
		<!-- end of main content -->
    </div> <!-- from header row atasnya sidebar-->
</div> <!-- from header container-fluid-->

<nav class="navbar fixed-bottom navbar-dark bg-dark">
  <small class="form-text text-muted">&copy yukmar 2018</small>
</nav>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?=base_url('assets/js/jquery-slim.min.js')?>"></script>
    <script src="<?=base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?=base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
  </body>
</html>
